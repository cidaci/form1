# Projeto JS Pizza Menu :pizza:

Site de Menu com Carrinho de compras para pedidos de pizzas.
Feito com HTML+CSS e JavaScript puro.

## Site Link: [JS Pizzas Menu][1]
### Feito no curso de Javascript da [B7Web][2]

[1]: https://capelaum-pizza-cart.netlify.app/
[2]: https://b7web.com.br/fullstack/
